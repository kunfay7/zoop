---
name: Add a site
about: Suggest a logo source that you would like us to add
title: ''
labels: ''
assignees: ''
---

**Name of the site**

**Website or home page URL**

**Git repo or how to get the list of logos**

**Additional info**
Any additional info or links that would help me add the site
